"use client";

import React from "react";
import { ConnectionProvider, WalletProvider } from "@solana/wallet-adapter-react";
import { WalletModalProvider } from "@solana/wallet-adapter-react-ui";
import { WalletAdapterNetwork } from "@solana/wallet-adapter-base";
import { clusterApiUrl } from "@solana/web3.js";
import {
  PhantomWalletAdapter,
  SolflareWalletAdapter,
} from "@solana/wallet-adapter-wallets";

// Import del CSS per il modal
import "@solana/wallet-adapter-react-ui/styles.css";

// Se serve definire un'interfaccia per le props
interface ProvidersProps {
  children: React.ReactNode;
}

// Questo componente è un Client Component
// perché abbiamo "use client" in cima al file
// e i provider di Solana funzionano in client-side React.
export default function Providers({ children }: ProvidersProps) {
  // Scegli la rete (mainnet, devnet, testnet)
  const network = WalletAdapterNetwork.Mainnet;
  const endpoint = clusterApiUrl(network);

  // Inizializzi i wallet che vuoi supportare
  const wallets = [
    new PhantomWalletAdapter(),
    new SolflareWalletAdapter({ network }),
    // ... altri se preferisci
  ];

  return (
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={wallets} autoConnect>
        {/* Il WalletModalProvider gestisce il popup “Connect Wallet” */}
        <WalletModalProvider>{children}</WalletModalProvider>
      </WalletProvider>
    </ConnectionProvider>
  );
}
