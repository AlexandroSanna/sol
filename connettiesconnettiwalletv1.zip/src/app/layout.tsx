import React from "react";
import "./globals.css"; // Importa i tuoi CSS globali se ne hai
import { Inter } from "next/font/google";
import Providers from "./providers"; // Importa il file client

// Puoi esportare i metadata (solo in un Server Component)
export const metadata = {
  title: "My SPL Deploy dApp",
  description: "DApp per creare SPL su Solana",
};

const inter = Inter({ subsets: ["latin"] });

// NESSUN "use client"; QUI --> layout.tsx resta un Server Component
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        {/* Avvolgiamo i nostri children nel Providers client-side */}
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
