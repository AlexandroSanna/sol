"use client";

import React from "react";
// Import dinamico di WalletMultiButton, con SSR disabilitato
import dynamic from "next/dynamic";

const WalletMultiButtonDynamic = dynamic(
  async () => (await import("@solana/wallet-adapter-react-ui")).WalletMultiButton,
  { ssr: false }
);

export default function HomePage() {
  return (
    <main style={{ padding: "24px" }}>
      <h1>Benvenuto nella dApp di esempio!</h1>
      {/* Qui usi la versione dinamica, che non fa SSR */}
      <WalletMultiButtonDynamic />
    </main>
  );
}
